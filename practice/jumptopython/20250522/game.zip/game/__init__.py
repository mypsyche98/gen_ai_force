from .graphic.render import render_test

VERSION = 3.5

def print_version_info():
  print(f"The version of this game is {VERSION}.")

print("Initializing game ...")